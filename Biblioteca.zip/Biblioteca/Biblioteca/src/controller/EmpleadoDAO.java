package controller;

import java.sql.*;
import Bd.ConnectionDB;
import java.util.ArrayList;
import java.util.List;
import model.Empleado;

public class EmpleadoDAO {
    // Listar todos los empleados
    public List<Object> getAll(){
        List<Object> listado = new ArrayList<>();
        String sql = "SELECT * FROM empleados ORDER BY id ASC;";
        try (Connection con = ConnectionDB.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);
            while(resultado.next()){
                Empleado emp = new Empleado();
                emp.setId(resultado.getInt("id"));
                emp.setNombre(resultado.getString("nombre"));
                emp.setApellido(resultado.getString("apellido"));
                emp.setPuesto(resultado.getString("puesto"));
                emp.setUsuario(resultado.getString("usuario"));
                emp.setPassword(resultado.getString("password"));
                emp.setTypeuser(resultado.getString("typeuser"));
                listado.add(emp);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar empleados: " + ex.getMessage());
        }
        return listado;
    }

    // Agregar un nuevo empleado
    public boolean insert(Object object){
        Empleado empleado = (Empleado) object;
        String sql = "INSERT INTO empleados (nombre, apellido, puesto, usuario, password, typeuser) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, empleado.getNombre());
            pst.setString(2, empleado.getApellido());
            pst.setString(3, empleado.getPuesto());
            pst.setString(4, empleado.getUsuario());
            pst.setString(5, empleado.getPassword());
            pst.setString(6, empleado.getTypeuser());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar empleado: " + ex.getMessage());
            return false;
        }
    }

    // Actualizar un empleado existente
    public int update(Object object) {
        Empleado empleado = (Empleado) object;
        String sql = "UPDATE empleados SET nombre=?, apellido=?, puesto=?, usuario=?, password=?, typeuser=? WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, empleado.getNombre());
            pst.setString(2, empleado.getApellido());
            pst.setString(3, empleado.getPuesto());
            pst.setString(4, empleado.getUsuario());
            pst.setString(5, empleado.getPassword());
            pst.setString(6, empleado.getTypeuser());
            pst.setInt(7, empleado.getId());
            return pst.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error al actualizar empleado: " + ex.getMessage());
            return 0;
        }
    }   

    // Eliminar un empleado por ID
    public boolean delete(int id) {
        String sql = "DELETE FROM empleados WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar empleado: " + ex.getMessage());
            return false;
        }
    }

    public Object getById(int id){
        String sql = "SELECT * FROM empleados WHERE id=?";
        Empleado empleado = new Empleado();
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet resultado = pst.executeQuery();
            if (resultado.next()) {
                empleado.setId(resultado.getInt("id"));
                empleado.setNombre(resultado.getString("nombre"));
                empleado.setApellido(resultado.getString("apellido"));
                empleado.setPuesto(resultado.getString("puesto"));
                empleado.setUsuario(resultado.getString("usuario"));
                empleado.setPassword(resultado.getString("password"));
                empleado.setTypeuser(resultado.getString("typeuser"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener empleado: " + ex.getMessage());
        }
        return empleado;
    }    
}
