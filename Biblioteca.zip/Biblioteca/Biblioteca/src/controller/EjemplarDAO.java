/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Bd.ConnectionDB;
import model.Ejemplar;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EjemplarDAO {

    public boolean insertar(Ejemplar e) {
        String sql = "INSERT INTO ejemplares (id_libro, cantidad, estado) VALUES (?, ?, ?)";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, e.getId_libro());
            stmt.setInt(2, e.getCantidad());
            stmt.setString(3, e.getEstado());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean actualizar(Ejemplar e) {
        String sql = "UPDATE ejemplares SET id_libro = ?, cantidad = ?, estado = ? WHERE id = ?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, e.getId_libro());
            stmt.setInt(2, e.getCantidad());
            stmt.setString(3, e.getEstado());
            stmt.setInt(4, e.getId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM ejemplares WHERE id = ?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public Ejemplar obtenerPorId(int id) {
        String sql = "SELECT * FROM ejemplares WHERE id = ?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Ejemplar(
                    rs.getInt("id"),
                    rs.getInt("id_libro"),
                    rs.getInt("cantidad"),
                    rs.getString("estado")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<Ejemplar> obtenerTodos() {
        List<Ejemplar> lista = new ArrayList<>();
        String sql = "SELECT * FROM ejemplares";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Ejemplar(
                    rs.getInt("id"),
                    rs.getInt("id_libro"),
                    rs.getInt("cantidad"),
                    rs.getString("estado")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }

    void eliminarEjemplaresDeLibro(int idLibro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean tienePrestamos(int idLibro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

