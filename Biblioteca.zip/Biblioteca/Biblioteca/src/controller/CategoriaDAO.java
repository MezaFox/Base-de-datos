/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import java.sql.*;
import Bd.ConnectionDB;
import java.util.ArrayList;
import java.util.List;
import model.Categoria;

public class CategoriaDAO {
    // Listar todas las categorías
        public List<Object> getAll(){
        List<Object> listado = new ArrayList<>();
        String sql = "SELECT * FROM categorias ORDER BY id ASC;";
        try (Connection con = ConnectionDB.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);
            while(resultado.next()){
                listado.add(new Categoria(
                    resultado.getInt("id"),
                    resultado.getString("nombre")
                ));
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar categorias: " + ex.getMessage());
        }
        return listado;
    }

    // Agregar una nueva categoría
 public boolean insert(Object object){
        Categoria categoria = (Categoria) object;
        String sql = "INSERT INTO categorias (nombre) VALUES (?)";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, categoria.getNombre());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar categoria: " + ex.getMessage());
            return false;
        }
    }

    // Actualizar una categoría existente
    public int update(Object object) {
        Categoria categoria = (Categoria) object;
        String sql = "UPDATE categorias SET nombre=? WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, categoria.getNombre());
            pst.setInt(2, categoria.getId());
        return pst.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error al actualizar categoria: " + ex.getMessage());
        return 0;
        }
    }

    // Eliminar una categoría por ID
    public boolean delete(int id) {
        String sql = "DELETE FROM categorias WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar categoria: " + ex.getMessage());
            return false;
        }
    }
    
        public Object getById(int id){
        String sql = "SELECT * FROM categorias WHERE id=?";
        Categoria categoria = new Categoria();
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet resultado = pst.executeQuery();
            if (resultado.next()) {
                categoria.setId(resultado.getInt("id"));
                categoria.setNombre(resultado.getString("nombre"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener categoria: " + ex.getMessage());
        }
        return categoria;
    }
}
