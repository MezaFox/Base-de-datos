package controller;

import Bd.ConnectionDB;
import model.Prestamo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class PrestamoDAO {

    public List<Object[]> getEjemplaresConId() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT libros.titulo, ejemplares.id FROM ejemplares JOIN libros ON ejemplares.id_libro = libros.id";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Object[]{ rs.getString("titulo"), rs.getInt("id") });
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener ejemplares: " + ex.getMessage());
        }
        return lista;
    }

    public Date getFechaPrestamoPorId(int idPrestamo) {
        String sql = "SELECT fecha_prestamo FROM prestamos WHERE id = ?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idPrestamo);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getDate("fecha_prestamo");
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener fecha de préstamo: " + e.getMessage());
        }
        return null;
    }

    public List<Object[]> getUsuariosConId() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT id, nombre FROM usuarios";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Object[]{ rs.getString("nombre"), rs.getInt("id") });
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener usuarios: " + ex.getMessage());
        }
        return lista;
    }

    public List<Object[]> getEmpleadosConId() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT id, nombre FROM empleados";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Object[]{ rs.getString("nombre"), rs.getInt("id") });
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener empleados: " + ex.getMessage());
        }
        return lista;
    }

    public List<Object> getAll() {
        List<Object> lista = new ArrayList<>();
        String sql = "SELECT * FROM prestamos";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Prestamo prestamo = new Prestamo(
                    rs.getInt("id"),
                    rs.getInt("id_ejemplar"),
                    rs.getInt("id_usuario"),
                    rs.getInt("id_empleado"),
                    rs.getDate("fecha_prestamo"),
                    rs.getDate("fecha_vencimiento"),
                    rs.getDate("fecha_devolucion")
                );
                lista.add(prestamo);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar préstamos: " + e.getMessage());
        }
        return lista;
    }

    public List<String> getEjemplares() {
        List<String> ejemplar = new ArrayList<>();
        String sql = "SELECT DISTINCT libros.titulo FROM ejemplares JOIN libros ON ejemplares.id_libro = libros.id;";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet resultado = stmt.executeQuery(sql)) {
            while (resultado.next()) {
                ejemplar.add(resultado.getString("titulo"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener tipos únicos: " + ex.getMessage());
        }
        return ejemplar;
    }

    public List<String> getEmpleados() {
        List<String> empleado = new ArrayList<>();
        String sql = "SELECT DISTINCT empleados.nombre FROM prestamos JOIN empleados ON prestamos.id_empleado = empleados.id;";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet resultado = stmt.executeQuery(sql)) {
            while (resultado.next()) {
                empleado.add(resultado.getString("nombre"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener tipos únicos: " + ex.getMessage());
        }
        return empleado;
    }

    // MÉTODO PARA OBTENER EL NOMBRE DEL USUARIO POR ID DE PRÉSTAMO
    public String getNombreUsuarioPorIdPrestamo(int id_prestamo) {
        String nombre = "";
        String sql = "SELECT u.nombre FROM prestamos p JOIN usuarios u ON p.id_usuario = u.id WHERE p.id = ?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id_prestamo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                nombre = rs.getString("nombre");
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener nombre de usuario: " + e.getMessage());
        }
        return nombre;
    }

    public List<Object[]> getPrestamosConNombres() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT " +
                     "p.id, u.nombre, e.nombre, ej.titulo, " +
                     "p.fecha_prestamo, p.fecha_vencimiento, p.fecha_devolucion " +
                     "FROM prestamos p " +
                     "JOIN usuarios u ON p.id_usuario = u.id " +
                     "JOIN empleados e ON p.id_empleado = e.id " +
                     "JOIN ejemplares ej ON p.id_ejemplar = ej.id";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Object[] fila = new Object[7];
                fila[0] = rs.getInt("id");
                fila[1] = rs.getString("u.nombre");
                fila[2] = rs.getString("e.nombre");
                fila[3] = rs.getString("ej.titulo");
                fila[4] = rs.getDate("fecha_prestamo");
                fila[5] = rs.getDate("fecha_vencimiento");
                fila[6] = rs.getDate("fecha_devolucion");
                lista.add(fila);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // MÉTODO INSERT QUE ACTUALIZA LA CANTIDAD DE EJEMPLARES
    public boolean insert(Object obj) {
        Prestamo prestamo = (Prestamo) obj;
        String sqlPrestamo = "INSERT INTO prestamos (id_ejemplar, id_usuario, id_empleado, fecha_prestamo, fecha_vencimiento, fecha_devolucion) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlUpdateEjemplar = "UPDATE ejemplares SET cantidad = cantidad - 1 WHERE id = ? AND cantidad > 0";
        Connection con = null;
        PreparedStatement pstPrestamo = null;
        PreparedStatement pstUpdateEjemplar = null;
        boolean exito = false;

        try {
            con = ConnectionDB.getConnection();
            con.setAutoCommit(false); // Inicia transacción

            // 1. Actualiza la cantidad de ejemplares (resta 1)
            pstUpdateEjemplar = con.prepareStatement(sqlUpdateEjemplar);
            pstUpdateEjemplar.setInt(1, prestamo.getId_ejemplar());
            int filasAfectadas = pstUpdateEjemplar.executeUpdate();

            if (filasAfectadas == 0) {
                // No hay ejemplares disponibles
                con.rollback();
                System.err.println("No hay ejemplares disponibles para prestar.");
                return false;
            }

            // 2. Inserta el préstamo
            pstPrestamo = con.prepareStatement(sqlPrestamo);
            pstPrestamo.setInt(1, prestamo.getId_ejemplar());
            pstPrestamo.setInt(2, prestamo.getId_usuario());
            pstPrestamo.setInt(3, prestamo.getId_empleado());
            pstPrestamo.setDate(4, prestamo.getFecha_prestamo());
            pstPrestamo.setDate(5, prestamo.getFecha_vencimiento());
            if (prestamo.getFecha_devolucion() != null) {
                pstPrestamo.setDate(6, prestamo.getFecha_devolucion());
            } else {
                pstPrestamo.setNull(6, java.sql.Types.DATE);
            }
            exito = pstPrestamo.executeUpdate() > 0;

            if (exito) {
                con.commit(); // Todo OK
            } else {
                con.rollback(); // Si falla el insert, revierte la resta
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar préstamo: " + e.getMessage());
            try {
                if (con != null) con.rollback();
            } catch (SQLException ex2) {
                System.err.println("Error al hacer rollback: " + ex2.getMessage());
            }
            exito = false;
        } finally {
            try {
                if (pstPrestamo != null) pstPrestamo.close();
                if (pstUpdateEjemplar != null) pstUpdateEjemplar.close();
                if (con != null) con.setAutoCommit(true);
                if (con != null) con.close();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar recursos: " + ex.getMessage());
            }
        }
        return exito;
    }

    public boolean update(Object obj) {
        Prestamo prestamo = (Prestamo) obj;
        String sql = "UPDATE prestamos SET id_ejemplar=?, id_usuario=?, id_empleado=?, fecha_prestamo=?, fecha_vencimiento=?, fecha_devolucion=? WHERE id=?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, prestamo.getId_ejemplar());
            pst.setInt(2, prestamo.getId_usuario());
            pst.setInt(3, prestamo.getId_empleado());
            pst.setDate(4, prestamo.getFecha_prestamo());
            pst.setDate(5, prestamo.getFecha_vencimiento());
            pst.setDate(6, prestamo.getFecha_devolucion());
            pst.setInt(7, prestamo.getId());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar préstamo: " + e.getMessage());
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM prestamos WHERE id=?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar préstamo: " + e.getMessage());
            return false;
        }
    }

    public Object getById(int id) {
        String sql = "SELECT * FROM prestamos WHERE id=?";
        Prestamo prestamo = new Prestamo();
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                prestamo.setId(rs.getInt("id"));
                prestamo.setId_ejemplar(rs.getInt("id_ejemplar"));
                prestamo.setId_usuario(rs.getInt("id_usuario"));
                prestamo.setId_empleado(rs.getInt("id_empleado"));
                prestamo.setFecha_prestamo(rs.getDate("fecha_prestamo"));
                prestamo.setFecha_vencimiento(rs.getDate("fecha_vencimiento"));
                prestamo.setFecha_devolucion(rs.getDate("fecha_devolucion"));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener préstamo: " + e.getMessage());
        }
        return prestamo;
    }
}