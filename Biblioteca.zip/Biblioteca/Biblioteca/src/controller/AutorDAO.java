/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.sql.*;
import Bd.ConnectionDB;
import java.util.ArrayList;
import java.util.List;
import model.Autor;

public class AutorDAO {
        // Listar todos los autores
        public List<Object> getAll(){
        List<Object> listado = new ArrayList<>();
        String sql = "SELECT * FROM autores ORDER BY id ASC;";
        try (Connection con = ConnectionDB.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);
            while(resultado.next()){
                listado.add(new Autor(
                    resultado.getInt("id"),
                    resultado.getString("nombre"),
                    resultado.getString("apellido")
                ));
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar autores: " + ex.getMessage());
        }
        return listado;
    }

    // Agregar un nuevo autor
 public boolean insert(Object object){
        Autor autor = (Autor) object;
        String sql = "INSERT INTO autores (nombre, apellido) VALUES (?, ?)";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, autor.getNombre());
            pst.setString(2, autor.getApellido());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar autor: " + ex.getMessage());
            return false;
        }
    }

    // Actualizar un autor existente
    public int update(Object object) {
        Autor autor = (Autor) object;
        String sql = "UPDATE autores SET nombre=?, apellido=? WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, autor.getNombre());
        pst.setString(2, autor.getApellido());
        pst.setInt(3, autor.getId());
        return pst.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error al actualizar autor: " + ex.getMessage());
        return 0;
        }
    }

    // Eliminar un autor por ID
    public boolean delete(int id) {
        String sql = "DELETE FROM autores WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar autor: " + ex.getMessage());
            return false;
        }
    }
    
        public Object getById(int id){
        String sql = "SELECT * FROM autores WHERE id=?";
        Autor autor = new Autor();
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet resultado = pst.executeQuery();
            if (resultado.next()) {
                autor.setId(resultado.getInt("id"));
                autor.setNombre(resultado.getString("nombre"));
                autor.setApellido(resultado.getString("apellido"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener autor: " + ex.getMessage());
        }
        return autor;
    }
}
