package controller;

import model.Devolucion;
import Bd.ConnectionDB;
import java.util.List;
import java.util.ArrayList;
import java.sql.*;

/**
 *
 * @author PC
 */
public class DevolucionDAO {

    public List<Object> getAll() {
        List<Object> lista = new ArrayList<>();
        String sql = "SELECT * FROM devoluciones";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Devolucion d = new Devolucion(
                        rs.getInt("id"),
                        rs.getInt("id_prestamo"),
                        rs.getDate("fecha_devolucion"),
                        rs.getString("observaciones")
                );
                lista.add(d);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar devoluciones: " + e.getMessage());
        }
        return lista;
    }

    public List<Object[]> getAllConNombres() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT d.id, u.nombre AS nombre_usuario, d.fecha_devolucion, d.observaciones " +
                "FROM devoluciones d " +
                "JOIN prestamos p ON d.id_prestamo = p.id " +
                "JOIN usuarios u ON p.id_usuario = u.id";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre_usuario"),
                        rs.getDate("fecha_devolucion"),
                        rs.getString("observaciones")
                });
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener devoluciones: " + e.getMessage());
        }
        return lista;
    }

    public List<Object[]> getDevolucionesConNombreUsuario() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT d.id, d.id_prestamo, u.nombre, d.fecha_devolucion, d.observaciones " +
                "FROM devoluciones d " +
                "JOIN prestamos p ON d.id_prestamo = p.id " +
                "JOIN usuarios u ON p.id_usuario = u.id";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Object[] fila = new Object[5];
                fila[0] = rs.getInt("id"); // ID devolución
                fila[1] = rs.getInt("id_prestamo");
                fila[2] = rs.getString("nombre"); // nombre del usuario
                fila[3] = rs.getDate("fecha_devolucion");
                fila[4] = rs.getString("observaciones");
                lista.add(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener devoluciones: " + e.getMessage());
        }
        return lista;
    }

    // MÉTODO INSERT QUE ACTUALIZA LA FECHA EN PRESTAMOS Y LA CANTIDAD DE EJEMPLARES
    public boolean insert(Object obj) {
        Devolucion d = (Devolucion) obj;
        String sqlInsert = "INSERT INTO devoluciones (id_prestamo, fecha_devolucion, observaciones) VALUES (?, ?, ?)";
        String sqlUpdatePrestamo = "UPDATE prestamos SET fecha_devolucion = ? WHERE id = ?";
        String sqlGetEjemplar = "SELECT id_ejemplar FROM prestamos WHERE id = ?";
        String sqlUpdateEjemplar = "UPDATE ejemplares SET cantidad = cantidad + 1 WHERE id = ?";
        Connection con = null;
        PreparedStatement pstInsert = null;
        PreparedStatement pstUpdatePrestamo = null;
        PreparedStatement pstGetEjemplar = null;
        PreparedStatement pstUpdateEjemplar = null;
        ResultSet rs = null;
        boolean exito = false;

        try {
            con = ConnectionDB.getConnection();
            con.setAutoCommit(false);

            // 1. Insertar la devolución
            pstInsert = con.prepareStatement(sqlInsert);
            pstInsert.setInt(1, d.getId_prestamo());
            pstInsert.setDate(2, d.getFecha_devolucion());
            pstInsert.setString(3, d.getObservaciones());
            int filasInsertadas = pstInsert.executeUpdate();

            if (filasInsertadas == 0) {
                con.rollback();
                System.err.println("No se pudo insertar la devolución.");
                return false;
            }

            // 2. Actualizar la fecha_devolucion en prestamos
            pstUpdatePrestamo = con.prepareStatement(sqlUpdatePrestamo);
            pstUpdatePrestamo.setDate(1, d.getFecha_devolucion());
            pstUpdatePrestamo.setInt(2, d.getId_prestamo());
            int filasActualizadas = pstUpdatePrestamo.executeUpdate();

            if (filasActualizadas == 0) {
                con.rollback();
                System.err.println("No se pudo actualizar la fecha de devolución en prestamos.");
                return false;
            }

            // 3. Obtener el id_ejemplar relacionado al préstamo
            pstGetEjemplar = con.prepareStatement(sqlGetEjemplar);
            pstGetEjemplar.setInt(1, d.getId_prestamo());
            rs = pstGetEjemplar.executeQuery();
            int idEjemplar = -1;
            if (rs.next()) {
                idEjemplar = rs.getInt("id_ejemplar");
            } else {
                con.rollback();
                System.err.println("No se encontró el préstamo relacionado.");
                return false;
            }

            // 4. Sumar 1 a la cantidad del ejemplar
            pstUpdateEjemplar = con.prepareStatement(sqlUpdateEjemplar);
            pstUpdateEjemplar.setInt(1, idEjemplar);
            int filasEjemplar = pstUpdateEjemplar.executeUpdate();

            if (filasEjemplar == 0) {
                con.rollback();
                System.err.println("No se pudo actualizar la cantidad del ejemplar.");
                return false;
            }

            con.commit();
            exito = true;
        } catch (SQLException e) {
            System.err.println("Error al insertar devolución: " + e.getMessage());
            try {
                if (con != null) con.rollback();
            } catch (SQLException ex2) {
                System.err.println("Error al hacer rollback: " + ex2.getMessage());
            }
            exito = false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstInsert != null) pstInsert.close();
                if (pstUpdatePrestamo != null) pstUpdatePrestamo.close();
                if (pstGetEjemplar != null) pstGetEjemplar.close();
                if (pstUpdateEjemplar != null) pstUpdateEjemplar.close();
                if (con != null) con.setAutoCommit(true);
                if (con != null) con.close();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar recursos: " + ex.getMessage());
            }
        }
        return exito;
    }

    public boolean update(Object obj) {
        Devolucion d = (Devolucion) obj;
        String sql = "UPDATE devoluciones SET id_prestamo=?, fecha_devolucion=?, observaciones=? WHERE id=?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, d.getId_prestamo());
            pst.setDate(2, d.getFecha_devolucion());
            pst.setString(3, d.getObservaciones());
            pst.setInt(4, d.getId());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar devolución: " + e.getMessage());
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM devoluciones WHERE id=?";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar devolución: " + e.getMessage());
            return false;
        }
    }

    public Object getById(int id) {
        String sql = "SELECT * FROM devoluciones WHERE id=?";
        Devolucion d = new Devolucion();
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                d.setId(rs.getInt("id"));
                d.setId_prestamo(rs.getInt("id_prestamo"));
                d.setFecha_devolucion(rs.getDate("fecha_devolucion"));
                d.setObservaciones(rs.getString("observaciones"));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener devolución: " + e.getMessage());
        }
        return d;
    }
}