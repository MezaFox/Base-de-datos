/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Usuario;
import Bd.ConnectionDB;
import java.util.List;
import java.util.ArrayList;
import java.sql.*;

/**
 *
 * @author PC
 */
public class UsuarioDAO {
    
        public List<Object> getAll(){
        List<Object> listado = new ArrayList<>();
        String sql = "SELECT * FROM usuarios;";
        try (Connection con = ConnectionDB.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);
            while(resultado.next()){
                listado.add(new Usuario(
                    resultado.getInt("id"),
                    resultado.getString("nombre"),
                    resultado.getString("apellido"),
                    resultado.getString("tipo"),
                    resultado.getString("email")
                ));
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar usuarios: " + ex.getMessage());
        }
        return listado;
    }
    
        //------------------------------------------------------------------------
        public List<String> getTiposUnicos() {
    List<String> tipos = new ArrayList<>();
    String sql = "SELECT DISTINCT tipo FROM usuarios";
    
    try (Connection con = ConnectionDB.getConnection();
         Statement stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        
        while (rs.next()) {
            tipos.add(rs.getString("tipo"));
        }
    } catch (SQLException ex) {
        System.err.println("Error al obtener tipos únicos: " + ex.getMessage());
    }
    
    return tipos;
}

        //------------------------------------------------------------------------
        
    public boolean insert(Object object){
        Usuario usuario = (Usuario) object;
        String sql = "INSERT INTO usuarios (nombre, apellido, tipo, email) VALUES (?, ?, ?, ?)";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, usuario.getNombre());
            pst.setString(2, usuario.getApellido());
            pst.setString(3, usuario.getTipo());
            pst.setString(4, usuario.getEmail());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar usuario: " + ex.getMessage());
            return false;
        }
    }
    public boolean update(Object object){
        Usuario usuario = (Usuario) object;
        String sql = "UPDATE usuarios SET nombre=?, apellido=?, tipo=?, email=? WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, usuario.getNombre());
            pst.setString(2, usuario.getApellido());
            pst.setString(3, usuario.getTipo());
            pst.setString(4, usuario.getEmail());
            pst.setInt(5, usuario.getId());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar usuario: " + ex.getMessage());
            return false;
        }
    }    
    
    public boolean delete(int id){
        String sql = "DELETE FROM usuarios WHERE id=?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar usuario: " + ex.getMessage());
            return false;
        }
    }

    public Object getById(int id){
        String sql = "SELECT * FROM usuarios WHERE id=?";
        Usuario usuario = new Usuario();
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet resultado = pst.executeQuery();
            if (resultado.next()) {
                usuario.setId(resultado.getInt("id"));
                usuario.setNombre(resultado.getString("nombre"));
                usuario.setApellido(resultado.getString("apellido"));
                usuario.setTipo(resultado.getString("tipo"));
                usuario.setEmail(resultado.getString("email"));
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener usuario: " + ex.getMessage());
        }
        return usuario;
    }

    
}
