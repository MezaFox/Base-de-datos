package controller;

import java.util.ArrayList;
import java.util.List;
import Bd.ConnectionDB;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import model.Libro;

public class LibroDAO {

    public List<Libro> getAll() {
        List<Libro> listado = new ArrayList<>();
        String sql = "SELECT * FROM libros;";
        try (Connection con = ConnectionDB.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet resultado = stmt.executeQuery(sql);
            while (resultado.next()) {
                listado.add(
                    new Libro(
                        resultado.getInt("id"),
                        resultado.getString("titulo"),
                        resultado.getInt("id_categoria"),
                        resultado.getInt("anio_publicacion"),
                        resultado.getString("isbn"),
                        resultado.getString("editorial")
                    )
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar Libros: " + ex.getMessage());
        }
        return listado;
    }

    public List<Object[]> getAutoresConId() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT id, nombre FROM autores";
        try (Connection con = ConnectionDB.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Object[]{ rs.getString("nombre"), rs.getInt("id") });
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener autores: " + ex.getMessage());
        }
        return lista;
    }

    public List<Object[]> getCategoriasConId() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT id, nombre FROM categorias;";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                lista.add(new Object[]{ rs.getString("nombre"), rs.getInt("id") });
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener categorías: " + e.getMessage());
        }
        return lista;
    }

    public boolean insert(Libro libro) {
        String sql = "INSERT INTO libros (titulo, id_categoria, anio_publicacion, isbn, editorial) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, libro.getTitulo());
            pst.setInt(2, libro.getId_categoria());
            pst.setInt(3, libro.getAnio_publicacion());
            pst.setString(4, libro.getIsbn());
            pst.setString(5, libro.getEditorial());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar Libros: " + ex.getMessage());
            return false;
        }
    }

    public boolean update(Libro libro) {
        String sql = "UPDATE libros SET titulo = ?, id_categoria = ?, anio_publicacion = ?, isbn = ?, editorial = ? WHERE id = ?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, libro.getTitulo());
            pst.setInt(2, libro.getId_categoria());
            pst.setInt(3, libro.getAnio_publicacion());
            pst.setString(4, libro.getIsbn());
            pst.setString(5, libro.getEditorial());
            pst.setInt(6, libro.getId());
            return pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar libro: " + ex.getMessage());
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM libros WHERE id = ?";
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar libro: " + ex.getMessage());
            return false;
        }
    }

    public Libro getById(int id) {
        String sql = "SELECT * FROM libros WHERE id = ?;";
        Libro libro = null;
        try (Connection con = ConnectionDB.getConnection()) {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet resultado = pst.executeQuery();
            if (resultado.next()) {
                libro = new Libro(
                    resultado.getInt("id"),
                    resultado.getString("titulo"),
                    resultado.getInt("id_categoria"),
                    resultado.getInt("anio_publicacion"),
                    resultado.getString("isbn"),
                    resultado.getString("editorial")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener libro por ID: " + ex.getMessage());
        }
        return libro;
    }

    public int insertAndGetId(Libro libro) {
        int idGenerado = -1;
        String sql = "INSERT INTO libros (titulo, id_categoria, anio_publicacion, isbn, editorial) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConnectionDB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, libro.getTitulo());
            pst.setInt(2, libro.getId_categoria());
            pst.setInt(3, libro.getAnio_publicacion());
            pst.setString(4, libro.getIsbn());
            pst.setString(5, libro.getEditorial());
            int filas = pst.executeUpdate();
            if (filas > 0) {
                ResultSet rs = pst.getGeneratedKeys();
                if (rs.next()) {
                    idGenerado = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar libro y obtener ID: " + e.getMessage());
        }
        return idGenerado;
    }

    // Método extra para eliminar libro y ejemplares solo si no tiene préstamos activos
    public boolean eliminarLibroSiNoPrestado(int idLibro) {
        EjemplarDAO ejemplarDAO = new EjemplarDAO();
        if (ejemplarDAO.tienePrestamos(idLibro)) {
            return false; // Hay préstamos activos, no eliminar
        }
        ejemplarDAO.eliminarEjemplaresDeLibro(idLibro);
        return delete(idLibro); // Usa tu método existente
    }
}