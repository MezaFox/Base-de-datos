package model;

public class Empleado {
    private int id;
    private String nombre;
    private String apellido;
    private String puesto;
    private String usuario;
    private String password;
    private String typeuser;

    public Empleado() {
    }

    // Constructor completo (puedes usarlo si lo necesitas)
    public Empleado(int id, String nombre, String apellido, String puesto, String usuario, String password, String typeuser) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.puesto = puesto;
        this.usuario = usuario;
        this.password = password;
        this.typeuser = typeuser;
    }

    // Constructor para compatibilidad con tu DAO anterior
    public Empleado(int id, String nombre, String apellido, String puesto) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.puesto = puesto;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getTypeuser() { return typeuser; }
    public void setTypeuser(String typeuser) { this.typeuser = typeuser; }
}