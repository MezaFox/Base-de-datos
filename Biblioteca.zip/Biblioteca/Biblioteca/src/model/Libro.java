/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;
import java.util.logging.Logger;

/**
 *
 * @author PC
 */
public class Libro {
    private int id;
    private String titulo;
    private int id_categoria;
    private int anio_publicacion;
    private String isbn;
    private String editorial;
    
    private static final Logger LOG = Logger.getLogger(Libro.class.getName());

    public Libro(int id, String titulo, int id_categoria, int anio_publicacion, String isbn, String editorial) {
        LOG.info("Se creo un objeto de Clase Libro");
        this.id = id;
        this.titulo = titulo;
        this.id_categoria = id_categoria;
        this.anio_publicacion = anio_publicacion;
        this.isbn = isbn;
        this.editorial = editorial;
    }

    public Libro() {
    
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public int getAnio_publicacion() {
        return anio_publicacion;
    }

    public void setAnio_publicacion(int anio_publicacion) {
        this.anio_publicacion = anio_publicacion;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 13 * hash + this.id;
        hash = 13 * hash + Objects.hashCode(this.titulo);
        hash = 13 * hash + this.id_categoria;
        hash = 13 * hash + this.anio_publicacion;
        hash = 13 * hash + Objects.hashCode(this.isbn);
        hash = 13 * hash + Objects.hashCode(this.editorial);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Libro other = (Libro) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.id_categoria != other.id_categoria) {
            return false;
        }
        if (this.anio_publicacion != other.anio_publicacion) {
            return false;
        }
        if (!Objects.equals(this.titulo, other.titulo)) {
            return false;
        }
        if (!Objects.equals(this.isbn, other.isbn)) {
            return false;
        }
        return Objects.equals(this.editorial, other.editorial);
    }
    
 
    
    
}
