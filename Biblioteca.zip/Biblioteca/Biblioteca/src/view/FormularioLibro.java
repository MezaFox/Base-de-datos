package view;

import controller.LibroDAO;
import java.util.List;
import java.util.HashMap;
import model.Libro;
import javax.swing.JOptionPane;


/**
 *
 * @author PC
 */
public class FormularioLibro extends javax.swing.JDialog {
private String mode;
private int id;
private LibroDAO dao;
private ListadoLibro parent;
private HashMap<String, Integer> mapCategorias = new HashMap<>();


    public FormularioLibro(ListadoLibro pParent, boolean modal, String pMode, int pId) {
        super(pParent, modal);
        this.parent = pParent;
        initComponents();

        setTitle("Registro Libro");
        this.setLocationRelativeTo(null);
        
        dao = new LibroDAO();
        
        this.mode = pMode;
        this.id = pId;
        txtid.setText(String.valueOf(pId));
        cargarCategoriasEnCombo();
        
        if(mode.equals("INS")){
            btnaccion.setText("Insertar");
        }else if(mode.equals("UPD")){
            Libro libro = (Libro) dao.getById(id);
            txttitulo.setText(libro.getTitulo());
            txtaniopublicacion.setText(String.valueOf(libro.getAnio_publicacion()));
            txtisbn.setText(libro.getIsbn());
            txteditorial.setText(libro.getEditorial());
            btnaccion.setText("Actualizar");
            
             for (String nombre : mapCategorias.keySet()) {
                if (mapCategorias.get(nombre).equals(libro.getId_categoria())) {
                    cbxcategoria.setSelectedItem(nombre);
                    break;
                }
            }
            
        }else if(mode.equals("DLT")){
            btnaccion.setText("Eliminar");
        } 
    }
    private void cargarCategoriasEnCombo() {
        cbxcategoria.removeAllItems();
        mapCategorias.clear();
        
        List<Object[]> categorias = dao.getCategoriasConId();

        for (Object[] cat : categorias) {
            String nombre = (String) cat[0];
            Integer id = (Integer) cat[1];
            mapCategorias.put(nombre, id);
            cbxcategoria.addItem(nombre);
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtid = new javax.swing.JTextField();
        txttitulo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtaniopublicacion = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtisbn = new javax.swing.JTextField();
        txteditorial = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnaccion = new javax.swing.JButton();
        btnsalir = new javax.swing.JButton();
        cbxcategoria = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cbxcategoria1 = new javax.swing.JComboBox<>();

        jLabel8.setFont(new java.awt.Font("PMingLiU-ExtB", 1, 18)); // NOI18N
        jLabel8.setText("DEVOLUCIONES");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(239, 219, 187));

        txtid.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtid.setEnabled(false);

        txttitulo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel1.setText("ID :");

        jLabel2.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel2.setText("Titulo :");

        txtaniopublicacion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtaniopublicacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtaniopublicacionKeyTyped(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel3.setText("Categoria :");

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel4.setText("Año Publicacion :");

        txtisbn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtisbn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtisbnActionPerformed(evt);
            }
        });
        txtisbn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtisbnKeyTyped(evt);
            }
        });

        txteditorial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel5.setText("ISBN :");

        jLabel6.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel6.setText("Editorial :");

        btnaccion.setBackground(new java.awt.Color(143, 210, 143));
        btnaccion.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnaccion.setText("Accion");
        btnaccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaccionActionPerformed(evt);
            }
        });

        btnsalir.setBackground(new java.awt.Color(255, 97, 97));
        btnsalir.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        btnsalir.setText("Cerrar");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });

        cbxcategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel9.setFont(new java.awt.Font("PMingLiU-ExtB", 1, 18)); // NOI18N
        jLabel9.setText("LIBROS");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(43, 43, 43))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addContainerGap())
        );

        jLabel7.setFont(new java.awt.Font("Microsoft YaHei", 0, 14)); // NOI18N
        jLabel7.setText("Autor :");

        cbxcategoria1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnaccion)
                        .addGap(237, 237, 237)
                        .addComponent(btnsalir))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6))
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel7))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txttitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtaniopublicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtisbn, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txteditorial, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxcategoria1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(121, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txttitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtaniopublicacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtisbn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txteditorial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxcategoria1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnaccion)
                    .addComponent(btnsalir))
                .addGap(61, 61, 61))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtisbnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtisbnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtisbnActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnsalirActionPerformed

    private void btnaccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaccionActionPerformed
        // TODO add your handling code here:
       if (mode.equals("INS")) {
    try {
        Libro libro = new Libro();
        libro.setTitulo(txttitulo.getText());
        String categoriaSeleccionada = (String) cbxcategoria.getSelectedItem();
        libro.setId_categoria(mapCategorias.get(categoriaSeleccionada));
        libro.setAnio_publicacion(Integer.parseInt(txtaniopublicacion.getText()));
        libro.setIsbn(txtisbn.getText());
        libro.setEditorial(txteditorial.getText());

        // 1. Insertar el libro y obtener el ID generado
        int idLibroNuevo = dao.insertAndGetId(libro); // Este método lo agregas tú (ver abajo)

        if (idLibroNuevo > 0) {
            // 2. Buscar o insertar el autor
            String nombreAutor = txteditorial1.getText().trim();
            int idAutor = -1;

            try (java.sql.Connection conn = Bd.ConnectionDB.getConnection()) {
                // Buscar si el autor ya existe
                String sqlBuscar = "SELECT id FROM autores WHERE nombre = ?";
                java.sql.PreparedStatement psBuscar = conn.prepareStatement(sqlBuscar);
                psBuscar.setString(1, nombreAutor);
                java.sql.ResultSet rs = psBuscar.executeQuery();
                if (rs.next()) {
                    idAutor = rs.getInt("id");
                } else {
                    // Insertar autor si no existe
                    String sqlInsert = "INSERT INTO autores (nombre) VALUES (?)";
                    java.sql.PreparedStatement psInsert = conn.prepareStatement(sqlInsert, java.sql.Statement.RETURN_GENERATED_KEYS);
                    psInsert.setString(1, nombreAutor);
                    psInsert.executeUpdate();
                    java.sql.ResultSet rsGen = psInsert.getGeneratedKeys();
                    if (rsGen.next()) {
                        idAutor = rsGen.getInt(1);
                    }
                }
                // Insertar en libro_autor
                if (idAutor > 0) {
                    String sqlLibroAutor = "INSERT INTO libro_autor (id_libro, id_autor) VALUES (?, ?)";
                    java.sql.PreparedStatement psLibroAutor = conn.prepareStatement(sqlLibroAutor);
                    psLibroAutor.setInt(1, idLibroNuevo);
                    psLibroAutor.setInt(2, idAutor);
                    psLibroAutor.executeUpdate();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al asociar autor: " + e.getMessage());
            }

            JOptionPane.showMessageDialog(this, "Libro y autor insertados correctamente.");
            parent.refrescarInfo();
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al insertar el libro.");
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Categoría y año deben ser números.");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
    }
        
       // -----------------------------------------------------------
        if (mode.equals("UPD")) {
        try {
            Libro libro = new Libro();
            libro.setId(id);
            libro.setTitulo(txttitulo.getText());
            String categoriaSeleccionada = (String) cbxcategoria.getSelectedItem();
                libro.setId_categoria(mapCategorias.get(categoriaSeleccionada));
            libro.setAnio_publicacion(Integer.parseInt(txtaniopublicacion.getText()));
            libro.setIsbn(txtisbn.getText());
            libro.setEditorial(txteditorial.getText());

            boolean exito = dao.update(libro);

            if (exito) {
                JOptionPane.showMessageDialog(this, "Libro actualizado correctamente.");
                parent.refrescarInfo();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el libro.");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Categoría y año deben ser números.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
     //--------------------------------------------------------------------------
        if (mode.equals("DLT")) {

                    boolean exito = dao.delete(id);

            if (exito) {
                JOptionPane.showMessageDialog(this, "Libro eliminado correctamente.");
                parent.refrescarInfo();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el libro.");
            }
        }
     
    }//GEN-LAST:event_btnaccionActionPerformed

    private void txtaniopublicacionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaniopublicacionKeyTyped
    char c = evt.getKeyChar();
    if (!Character.isDigit(c)) {
        evt.consume();
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaniopublicacionKeyTyped

    private void txtisbnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtisbnKeyTyped
char c = evt.getKeyChar();

// Si no es dígito, no lo deja escribir
if (!Character.isDigit(c)) {
    evt.consume();
}

// Si ya hay 13 caracteres, no permite más
if (txtisbn.getText().length() >= 13) {
    evt.consume();
}
    }//GEN-LAST:event_txtisbnKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormularioLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormularioLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormularioLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormularioLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FormularioLibro dialog = new FormularioLibro(new ListadoLibro(), true, "INS", 0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnaccion;
    private javax.swing.JButton btnsalir;
    private javax.swing.JComboBox<String> cbxcategoria;
    private javax.swing.JComboBox<String> cbxcategoria1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField txtaniopublicacion;
    private javax.swing.JTextField txteditorial;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtisbn;
    private javax.swing.JTextField txttitulo;
    // End of variables declaration//GEN-END:variables
}
